/* ==========================================================================
   اردو دوم سال — Service Worker
   Caches the whole site (lessons, vocab bank, flashcards, styles, scripts,
   icons, and the fonts they depend on) so the site works fully offline
   after the first visit. Bump CACHE_VERSION whenever site files change so
   phones pick up the update instead of serving a stale copy forever.
   ========================================================================== */

const CACHE_VERSION = 'v43';
const CACHE_NAME = 'urdu-pub-' + CACHE_VERSION;

/* Every page + local asset, so a first visit to index.html primes the whole
   site for offline use (not just the page that was open). */
const PRECACHE_URLS = [
  './',
  'index.html',
  'share.html',
  'whatsnew.html',
  'assets/js/site-config.js',
  'assets/js/community.js',
  'assets/img/qr.png',
  'vocabulary.html',
  'flashcards.html',
  'privacy.html',
  'terms.html',
  'me.html',
  'about.html',
  'assets/img/me.jpg',
  'assets/js/layout.js',
  'nasr-1.html', 'nasr-2.html', 'nasr-3.html', 'nasr-4.html', 'nasr-5.html',
  'nasr-6.html', 'nasr-7.html', 'nasr-8.html', 'nasr-9.html', 'nasr-10.html',
  'nasr-11.html', 'nasr-12.html', 'nasr-13.html', 'nasr-14.html', 'nasr-15.html',
  'nasr-16.html', 'nasr-17.html',
  'nazam-1.html', 'nazam-2.html', 'nazam-3.html', 'nazam-4.html', 'nazam-5.html',
  'nazam-6.html', 'nazam-7.html', 'nazam-8.html',
  'ghazal-9.html', 'ghazal-10.html', 'ghazal-11.html', 'ghazal-12.html',
  'ghazal-13.html', 'ghazal-14.html', 'ghazal-15.html', 'ghazal-16.html',
  'manifest.json',
  'assets/css/style.css',
  'assets/js/app.js',
  'assets/js/extras.js',
  'assets/js/theme.js',
  'assets/js/nav-scroll.js',
  'assets/js/ripple.js',
  'assets/js/page-transitions.js',
  'assets/js/vocab.js',
  'assets/js/firebase-config.js',
  'assets/js/gate.js',
  'assets/js/install.js',
  'assets/js/notify.js',
  'assets/js/auth.js',
  'assets/js/mq-boot.js',
  'assets/css/mq-urdu.css',
  'assets/js/flashcards.js',
  'assets/icons/icon-192.png',
  'assets/icons/icon-512.png',
  'assets/icons/icon-512-maskable.png',
  'assets/icons/apple-touch-icon.png',
  /* pinned icon library — cached on install so icons also work offline on a first visit */
  'https://unpkg.com/lucide@0.468.0',
];

/* Third-party origins the site depends on visually (Google Fonts CSS + the
   actual woff2 files it points to, and the lucide icon script). Cached
   opaque/cors as available — cache-first once fetched successfully. */
const RUNTIME_CACHE_ORIGINS = [
  'https://fonts.googleapis.com',
  'https://fonts.gstatic.com',
  'https://unpkg.com',
  'https://www.gstatic.com',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) =>
        /* One file failing to download must not sabotage every other file —
           cache.addAll() used to be all-or-nothing, so a single missing
           asset (this bit us with icon-512.png before) silently failed the
           *entire* precache, leaving the installed app with nothing to fall
           back on the next time it couldn't reach the server. */
        Promise.all(
          PRECACHE_URLS.map((url) =>
            cache.add(url).catch((err) => console.warn('[service-worker] precache failed for', url, err))
          )
        )
      )
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((names) => Promise.all(
        names.filter((name) => name.indexOf('urdu-pub-') === 0 && name !== CACHE_NAME).map((name) => caches.delete(name))
      ))
      .then(() => self.clients.claim())
  );
});

/* Let the page tell a waiting worker to activate immediately (used after
   showing the person an "update available" prompt, if one is added later). */
self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});

function isRuntimeCacheable(url) {
  return RUNTIME_CACHE_ORIGINS.some((origin) => url.startsWith(origin));
}

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = req.url;
  const sameOrigin = url.startsWith(self.location.origin);
  if (url.indexOf('announcement.json') !== -1) return;

  if (sameOrigin && req.mode === 'navigate') {
    /* HTML pages: stale-while-revalidate — show the cached lesson instantly
       (works offline, feels instant on a slow connection), then quietly
       refresh the cache in the background when online. If a page was never
       cached AND the network fails (e.g. server unreachable), fall back to
       the cached homepage rather than letting the browser show its own
       offline error page. */
    event.respondWith(
      caches.match(req).then((cached) => {
        const network = fetch(req).then((res) => {
          if (res && res.ok) caches.open(CACHE_NAME).then((cache) => cache.put(req, res.clone()));
          return res;
        }).catch(() => cached || caches.match('index.html'));
        return cached || network;
      })
    );
    return;
  }

  if (sameOrigin || isRuntimeCacheable(url)) {
    /* CSS/JS/icons/fonts: cache-first, since these rarely change moment to
       moment and this keeps things instant + fully offline. */
    event.respondWith(
      caches.match(req).then((cached) => {
        if (cached) return cached;
        return fetch(req).then((res) => {
          if (res && (res.ok || res.type === 'opaque')) {
            caches.open(CACHE_NAME).then((cache) => cache.put(req, res.clone()));
          }
          return res;
        }).catch(() => cached);
      })
    );
  }
});
