/* Edit "goatcounter" to your GoatCounter code to turn on visitor stats. */
window.COMMUNITY={
 "url": "https://physicswijaz-commits.github.io/Urdu-p-2nd-year/",
 "wa": "923409368103",
 "goatcounter": "",
 "S": {
  "share": "شیئر کریں",
  "whatsnew": "نیا کیا ہے",
  "report": "غلطی بتائیں",
  "share_title": "سائٹ شیئر کریں",
  "share_p": "سائٹ کا لنک کسی دوست کو بھیجیں۔ لنک کھولنے کے بعد نوٹس دیکھنے کے لیے سائن اِن کرنا ہوگا اور ایڈمن کی منظوری درکار ہوگی۔",
  "wa_btn": "واٹس ایپ پر شیئر کریں",
  "sys_btn": "شیئر…",
  "copy_btn": "لنک کاپی کریں",
  "copied": "لنک کاپی ہو گیا",
  "qr_title": "کھولنے کے لیے اسکین کریں",
  "qr_p": "یہ کوڈ کسی ہم جماعت کو دکھائیں، وہ اپنے فون کے کیمرے سے اسکین کر کے سائٹ کھول سکتا ہے۔",
  "share_msg": "کے پی کے بورڈ دوم سال اردو نوٹس: ",
  "report_msg": "غلطی کی اطلاع",
  "back": "واپس",
  "new_title": "نیا کیا ہے",
  "new_intro": "سائٹ میں حالیہ تبدیلیاں، تازہ ترین سب سے اوپر۔",
  "dismiss": "بند کریں",
  "tab": "شیئر"
 }
};
