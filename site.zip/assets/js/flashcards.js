/* ==========================================================================
   فلیش کارڈز — Flashcards page logic (flashcards.html)
   ========================================================================== */
document.addEventListener('DOMContentLoaded', () => {
  if (typeof VOCAB_CORE === 'undefined') return;

  const PROGRESS_KEY = 'flashcardProgress'; // { "word-lowercase": "know" | "learning" }
  const SRS_KEY = 'srsProgress'; // { "word-lowercase": { level: 0-6, next: timestamp } }
  const MINE_KEY = 'myVocab';

  /* Leitner-style leveled intervals (days). Level 0 = due immediately (new
     or just-missed word); each correct answer moves up a level and pushes
     the next review further out; a miss drops straight back to level 0. */
  const SRS_INTERVAL_DAYS = [0, 1, 3, 7, 14, 30, 60];

  function loadMine() {
    try { return JSON.parse(localStorage.getItem(MINE_KEY) || '[]'); }
    catch (e) { return []; }
  }
  function loadProgress() {
    try { return JSON.parse(localStorage.getItem(PROGRESS_KEY) || '{}'); }
    catch (e) { return {}; }
  }
  function saveProgress(p) { localStorage.setItem(PROGRESS_KEY, JSON.stringify(p)); }

  function loadSrs() {
    try { return JSON.parse(localStorage.getItem(SRS_KEY) || '{}'); }
    catch (e) { return {}; }
  }
  function saveSrs(s) { localStorage.setItem(SRS_KEY, JSON.stringify(s)); }

  function isDue(key) {
    const rec = srs[key];
    return !rec || rec.next <= Date.now();
  }

  function reviewWord(key, correct) {
    const rec = srs[key] || { level: 0, next: 0 };
    if (correct) {
      rec.level = Math.min(rec.level + 1, SRS_INTERVAL_DAYS.length - 1);
    } else {
      rec.level = 0;
    }
    rec.next = Date.now() + SRS_INTERVAL_DAYS[rec.level] * 86400000;
    srs[key] = rec;
    saveSrs(srs);
    updateDueBadge();
  }

  function updateDueBadge() {
    if (!dueBadge) return;
    const dueCount = allEntries().filter((e) => isDue(e.word.toLowerCase())).length;
    dueBadge.textContent = dueCount;
  }

  function allEntries() {
    const mine = loadMine().map((w) => ({ ...w, source: 'mine' }));
    return VOCAB_CORE.concat(mine);
  }

  function tagLabel(e) {
    if (e.source === 'mine') return '★ میرا لفظ';
    const parts = [];
    if (e.type) parts.push(e.type);
    if (e.chapter) parts.push('سبق ' + e.chapter);
    return parts.join(' · ');
  }

  const filtersEl = document.getElementById('fc-filters');
  const card = document.getElementById('fc-card');
  const wordEl = document.getElementById('fc-word');
  const tagEl = document.getElementById('fc-tag');
  const meaningEl = document.getElementById('fc-meaning');
  const exampleEl = document.getElementById('fc-example');
  const progressText = document.getElementById('fc-progress-text');
  const stage = document.getElementById('fc-stage');
  const actions = document.querySelector('.fc-actions');
  const emptyEl = document.getElementById('fc-empty');
  const emptyText = document.getElementById('fc-empty-text');
  const dueBadge = document.getElementById('fc-due-badge');

  let filter = 'all';
  let deck = [];
  let pos = 0;
  let progress = loadProgress();
  let srs = loadSrs();

  function buildDeck() {
    const entries = allEntries();
    let pool = entries;
    if (filter === 'mine') pool = entries.filter((e) => e.source === 'mine');
    if (filter === 'learning') pool = entries.filter((e) => progress[e.word.toLowerCase()] === 'learning');
    if (filter === 'due') pool = entries.filter((e) => isDue(e.word.toLowerCase()));

    if (filter === 'due') {
      // Most-overdue (and brand-new) words first — no shuffle, no doubling.
      deck = pool.slice().sort((a, b) => {
        const na = (srs[a.word.toLowerCase()] || { next: 0 }).next;
        const nb = (srs[b.word.toLowerCase()] || { next: 0 }).next;
        return na - nb;
      });
      pos = 0;
      updateDueBadge();
      return;
    }

    // Weight: words marked "still learning" show up twice as often this session.
    let weighted = [];
    pool.forEach((e) => {
      const status = progress[e.word.toLowerCase()];
      weighted.push(e);
      if (status === 'learning') weighted.push(e);
    });
    // Shuffle (Fisher–Yates)
    for (let i = weighted.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [weighted[i], weighted[j]] = [weighted[j], weighted[i]];
    }
    deck = weighted;
    pos = 0;
    updateDueBadge();
  }

  function showCard() {
    card.classList.remove('flipped');
    if (!deck.length) {
      stage.style.display = 'none';
      actions.style.display = 'none';
      document.querySelector('.fc-progress-row').style.display = 'none';
      emptyEl.style.display = 'block';
      emptyText.textContent = filter === 'learning'
        ? 'آپ نے اپنی \u201cابھی سیکھ رہا ہوں\u201d فہرست مکمل کر لی — شاباش! فلٹر بدلیں یا نئے الفاظ شامل کریں۔'
        : filter === 'due'
          ? 'آج کے لیے دہرانے والا کوئی لفظ باقی نہیں — شاباش! 🎉 کل واپس آئیں۔'
          : 'اس فلٹر میں کوئی لفظ موجود نہیں۔';
      return;
    }
    stage.style.display = '';
    actions.style.display = '';
    document.querySelector('.fc-progress-row').style.display = '';
    emptyEl.style.display = 'none';

    const entry = deck[pos];
    wordEl.textContent = entry.word;
    tagEl.textContent = tagLabel(entry);
    meaningEl.textContent = entry.meaning;
    exampleEl.textContent = entry.example ? '\u201c' + entry.example + '\u201d' : '';
    exampleEl.style.display = entry.example ? '' : 'none';
    progressText.textContent = (pos + 1) + ' / ' + deck.length;
  }

  function advance() {
    pos++;
    if (pos >= deck.length) buildDeck();
    showCard();
  }

  function mark(status) {
    if (!deck.length) return;
    const word = deck[pos].word.toLowerCase();
    progress[word] = status;
    saveProgress(progress);
    reviewWord(word, status === 'know');
    advance();
  }

  card.addEventListener('click', () => card.classList.toggle('flipped'));
  document.getElementById('fc-mark-learning').addEventListener('click', () => mark('learning'));
  document.getElementById('fc-mark-know').addEventListener('click', () => mark('know'));
  document.getElementById('fc-shuffle').addEventListener('click', () => { buildDeck(); showCard(); });

  filtersEl.addEventListener('click', (e) => {
    const btn = e.target.closest('.vb-filter-chip');
    if (!btn) return;
    filtersEl.querySelectorAll('.vb-filter-chip').forEach((c) => c.classList.remove('active'));
    btn.classList.add('active');
    filter = btn.dataset.filter;
    buildDeck();
    showCard();
  });

  buildDeck();
  showCard();
});
