/* مطالعہ قرآن — sign-in screen (reusable).
   Hides the page until the student is signed in and approved, and swaps the lesson loaders for the protected database (see auth.js).
   Re-use on another site: set window.MQ_BRAND = {title, tag} before this file and keep the same Firebase project. */
(function(){
'use strict';
var MQ=window.MQ=window.MQ||{};
var page=document.body?document.body.getAttribute('data-page'):'';
if(page==='doc')return;
var BR=window.MQ_BRAND||{title:'مطالعہ قرآن',tag:'قرآن فہمی کا آسان ساتھی'};
var wa=(MQ.config&&MQ.config.links&&MQ.config.links.whatsapp)||'';
MQ.authReady=new Promise(function(res){ MQ._authOk=res; });
/* returning students: skip the loading screen and show the page from cache at once; auth.js double-checks in the background */
var fast=false; try{ fast=!!localStorage.getItem('mq_ok'); }catch(e){}
MQ._fast=fast; if(fast) MQ._authOk();
MQ._fb=new Promise(function(r){ MQ._fbOk=r; });
MQ.fetchDoc=function(k){ return MQ._fb.then(function(f){ return f(k); }); };

/* ---------- styles ---------- */
var css=''
+'#mq-gate{position:fixed;inset:0;z-index:99999;overflow:auto;-webkit-overflow-scrolling:touch;color:var(--text,#14231C);font-family:var(--f-ui,system-ui,-apple-system,"Segoe UI",Roboto,sans-serif);line-height:1.9;'
+'background:radial-gradient(1200px 520px at 50% -140px,rgba(42,116,89,.22),transparent 70%),var(--cream,#F5F8F3);animation:gIn .35s ease both}'
+'#mq-gate *{box-sizing:border-box}'
+'#mq-gate .gwrap{min-height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:max(20px,env(safe-area-inset-top)) 16px max(20px,env(safe-area-inset-bottom))}'
+'#mq-gate .glogo{width:68px;height:68px;border-radius:20px;display:grid;place-items:center;background:linear-gradient(145deg,var(--primary,#2A7459),var(--primary-dark,#1B4E3C));box-shadow:0 10px 28px rgba(31,95,74,.35),inset 0 1px 0 rgba(255,255,255,.25);margin:0 auto 14px}'
+'#mq-gate .glogo svg{width:38px;height:38px}'
+'#mq-gate h1{margin:0;font-size:1.55rem;font-weight:700;text-align:center;line-height:1.7}'
+'#mq-gate .gsub{margin:0 0 18px;text-align:center;opacity:.72;font-size:.95rem}'
+'#mq-gate .gcard{width:100%;max-width:392px;background:var(--white,#fff);border:1px solid var(--border,#D9E5DC);border-radius:24px;padding:22px 18px 18px;box-shadow:0 14px 44px rgba(20,35,28,.10);animation:gUp .4s cubic-bezier(.2,.8,.2,1) both}'
+'#mq-gate .gbtn,#mq-gate .pbtn,#mq-gate .sbtn{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;min-height:48px;padding:10px 14px;border-radius:14px;font:inherit;font-weight:600;font-size:1rem;cursor:pointer;text-decoration:none;transition:transform .15s,box-shadow .2s,opacity .2s;-webkit-tap-highlight-color:transparent}'
+'#mq-gate .gbtn{background:var(--white,#fff);color:inherit;border:1px solid var(--border,#D9E5DC);box-shadow:0 1px 2px rgba(0,0,0,.05)}'
+'#mq-gate .gbtn:active,#mq-gate .pbtn:active,#mq-gate .sbtn:active{transform:scale(.98)}'
+'#mq-gate .gbtn svg{width:20px;height:20px;flex:none}'
+'#mq-gate .pbtn{border:0;background:linear-gradient(145deg,var(--btn,#2A7459),var(--primary-dark,#1F5F4A));color:#fff;box-shadow:0 6px 16px rgba(31,95,74,.28);margin-top:6px}'
+'#mq-gate .sbtn{background:transparent;border:1px solid var(--border,#D9E5DC);color:inherit;margin-top:10px}'
+'#mq-gate button[disabled]{opacity:.65;cursor:default}'
+'#mq-gate .gor{display:flex;align-items:center;gap:12px;margin:16px 0;opacity:.55;font-size:.85rem}'
+'#mq-gate .gor:before,#mq-gate .gor:after{content:"";flex:1;height:1px;background:var(--border,#D9E5DC)}'
+'#mq-gate .tabs{display:grid;grid-template-columns:1fr 1fr;gap:4px;padding:4px;margin-bottom:14px;border-radius:14px;background:var(--soft,#EDF3EE)}'
+'#mq-gate .tabs button{border:0;border-radius:11px;padding:8px;font:inherit;font-weight:600;font-size:.95rem;color:inherit;background:transparent;cursor:pointer;opacity:.7;transition:all .2s}'
+'#mq-gate .tabs button.on{background:var(--white,#fff);opacity:1;box-shadow:0 1px 4px rgba(0,0,0,.1)}'
+'#mq-gate label{display:block;font-size:.85rem;font-weight:600;margin:10px 2px 3px;opacity:.85}'
+'#mq-gate .fld{position:relative;direction:ltr}'
+'#mq-gate .fld>svg.ic{position:absolute;left:13px;top:50%;margin-top:-9px;width:18px;height:18px;opacity:.45;pointer-events:none}'
+'#mq-gate .fld input{width:100%;height:48px;padding:0 44px 0 40px;border-radius:14px;border:1.5px solid var(--border,#D9E5DC);background:var(--cream,#F8FAF8);color:inherit;font:inherit;font-size:16px;outline:0;transition:border-color .2s,box-shadow .2s,background .2s;text-align:left}'
+'#mq-gate .fld input:focus{border-color:var(--btn,#2A7459);background:var(--white,#fff);box-shadow:0 0 0 4px rgba(42,116,89,.14)}'
+'#mq-gate .fld.bad input{border-color:var(--bad,#C94A4A);box-shadow:0 0 0 4px rgba(201,74,74,.10)}'
+'#mq-gate .fld .eye{position:absolute;right:4px;top:4px;width:40px;height:40px;border:0;background:none;color:inherit;opacity:.55;cursor:pointer;display:grid;place-items:center;border-radius:12px}'
+'#mq-gate .fld .eye svg{width:20px;height:20px}'
+'#mq-gate .hint{font-size:.78rem;opacity:.6;margin:3px 3px 0}'
+'#mq-gate .fe{font-size:.8rem;color:var(--bad,#C94A4A);margin:3px 3px 0}'
+'#mq-gate .gerr,#mq-gate .okm{display:flex;gap:8px;align-items:flex-start;margin:0 0 12px;padding:10px 12px;border-radius:12px;font-size:.9rem;line-height:1.8}'
+'#mq-gate .gerr{background:rgba(201,74,74,.10);color:var(--bad,#B83B3B)}#mq-gate .okm{background:rgba(31,138,91,.12);color:#1B7A50}'
+'#mq-gate .lnk{display:block;margin:12px auto 0;border:0;background:none;color:var(--primary,#2A7459);font:inherit;font-size:.9rem;font-weight:600;cursor:pointer;text-align:center}'
+'#mq-gate .foot{margin-top:16px;font-size:.78rem;opacity:.6;text-align:center}'
+'#mq-gate .foot a{color:inherit;margin:0 6px}'
+'#mq-gate .gstate{text-align:center;padding:6px 0 2px}'
+'#mq-gate .gstate .bi{width:64px;height:64px;border-radius:50%;display:grid;place-items:center;margin:0 auto 10px;background:var(--soft,#EDF3EE)}'
+'#mq-gate .gstate .bi svg{width:32px;height:32px}'
+'#mq-gate .gstate h2{margin:0 0 4px;font-size:1.2rem}'
+'#mq-gate .gstate p{margin:0 0 8px;opacity:.82;font-size:.95rem}'
+'#mq-gate .mail{direction:ltr;display:inline-block;max-width:100%;padding:4px 12px;margin:2px 0 8px;border-radius:99px;background:var(--soft,#EDF3EE);font-size:.82rem;word-break:break-all}'
+'#mq-gate .spin{width:18px;height:18px;border-radius:50%;border:2.5px solid rgba(255,255,255,.4);border-top-color:#fff;animation:gSp .7s linear infinite;flex:none}'
+'#mq-gate .spin.dk{border-color:rgba(42,116,89,.25);border-top-color:var(--primary,#2A7459)}'
+'#mq-gate .splash{display:grid;place-items:center;gap:16px;min-height:100%;align-content:center}'
+'#mq-gate .splash .logo{animation:gPulse 1.6s ease-in-out infinite}'
+'#mq-gate .gring{position:relative;width:104px;height:104px;display:grid;place-items:center}'
+'#mq-gate .gring:before{content:"";position:absolute;inset:0;border-radius:50%;border:4px solid var(--border,#D9E5DC);border-top-color:var(--btn,#2A7459);border-right-color:var(--btn,#2A7459);animation:gSp .85s linear infinite}'
+'#mq-gate .gring .glogo{margin:0;width:64px;height:64px;border-radius:19px}'
+'@keyframes gSp{to{transform:rotate(360deg)}}@keyframes gIn{from{opacity:0}}@keyframes gUp{from{opacity:0;transform:translateY(14px)}}'
+'@keyframes gPulse{50%{transform:scale(1.07)}}@keyframes gBar{0%{transform:translateX(-100%)}100%{transform:translateX(300%)}}'
+'@media(prefers-reduced-motion:reduce){#mq-gate *{animation:none!important;transition:none!important}}'
+'html[data-theme=dark] #mq-gate .fld input{background:rgba(255,255,255,.04)}';
var st=document.createElement('style'); st.id='mq-gate-css'; st.textContent=css; document.head.appendChild(st);

/* ---------- icons (inline so they work offline) ---------- */
function ico(p,extra){ return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" '+(extra||'')+'>'+p+'</svg>'; }
var ST='style="width:18px;height:18px;flex:none;margin-top:5px"';
var I=MQ.icons={
  user:ico('<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>','class="ic"'),
  at:ico('<circle cx="12" cy="12" r="4"/><path d="M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-4 8"/>','class="ic"'),
  lock:ico('<rect x="4" y="11" width="16" height="10" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>','class="ic"'),
  mail:ico('<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="m3.5 7 8.5 6 8.5-6"/>','class="ic"'),
  eye:ico('<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>'),
  eyeoff:ico('<path d="M3 3l18 18M10.6 5.1A9.7 9.7 0 0 1 12 5c6.4 0 10 7 10 7a17 17 0 0 1-3.2 4M6.5 6.6A16.6 16.6 0 0 0 2 12s3.6 7 10 7a9.6 9.6 0 0 0 4.3-1"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/>'),
  alert:ico('<circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16.5v.1"/>',ST),
  check:ico('<circle cx="12" cy="12" r="9"/><path d="m8 12.5 2.8 2.8L16 9.5"/>',ST),
  clock:ico('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
  ban:ico('<circle cx="12" cy="12" r="9"/><path d="m5.7 5.7 12.6 12.6"/>'),
  tool:ico('<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.6 2.6-2.4-.6-.6-2.4z"/>'),
  wifi:ico('<path d="M2 9a15 15 0 0 1 20 0M5 12.5a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0"/><path d="M12 19.5v.1"/>'),
  hourglass:ico('<path d="M6 3h12M6 21h12M7 3c0 5 5 6 5 9s-5 4-5 9M17 3c0 5-5 6-5 9s5 4 5 9"/>')
};
var GOOGLE='<svg viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.6 5.9c4.4-4.1 7-10.1 7-17.6z"/><path fill="#FBBC05" d="M10.5 28.7A14.5 14.5 0 0 1 9.5 24c0-1.6.3-3.2.8-4.7l-7.9-6.1A24 24 0 0 0 0 24c0 3.9.9 7.5 2.6 10.8l7.9-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.6-5.9c-2.1 1.4-4.9 2.3-8.3 2.3-6.3 0-11.6-4.1-13.5-9.8l-7.9 6.1C6.5 42.6 14.6 48 24 48z"/></svg>';
var LOGO='<svg viewBox="0 0 48 48" fill="none"><path d="M24 12c-4-3-9-4-15-3v26c6-1 11 0 15 3 4-3 9-4 15-3V9c-6-1-11 0-15 3z" fill="rgba(255,255,255,.18)" stroke="#fff" stroke-width="2.4" stroke-linejoin="round"/><path d="M24 12v26" stroke="#fff" stroke-width="2.4"/><path d="M33.5 17.2a5 5 0 1 0 0 8 4 4 0 1 1 0-8z" fill="#FFD966"/></svg>';

/* ---------- helpers ---------- */
var ov=document.createElement('div'); ov.id='mq-gate'; ov.setAttribute('role','dialog'); ov.setAttribute('aria-live','polite'); ov.setAttribute('aria-label',BR.title);
document.body.appendChild(ov); if(fast) ov.style.display='none';
function esc(s){ return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];}); }
function $(id){ return document.getElementById(id); }
function on(id,fn){ var e=$(id); if(e) e.onclick=fn; }
function frame(inner,sub,foot){
  ov.innerHTML='<div class="gwrap"><div class="glogo">'+LOGO+'</div><h1>'+esc(BR.title)+'</h1><p class="gsub">'+esc(sub||BR.tag)+'</p><div class="gcard">'+inner+'</div>'+(foot===false?'':'<div class="foot"><a href="terms.html">شرائط</a>·<a href="privacy.html">رازداری</a></div>')+'</div>';
}
function spin(dk){ return '<span class="spin'+(dk?' dk':'')+'"></span>'; }
function busyBtn(b,on_,dark){
  if(!b) return;
  if(on_){ b._h=b.innerHTML; b.disabled=true; b.innerHTML=spin(dark)+(dark?'':'<span>براہِ کرم انتظار کریں…</span>'); }
  else { b.disabled=false; if(b._h) b.innerHTML=b._h; }
}
var ERR={
  'auth/invalid-credential':'یوزر نیم / ای میل یا پاس ورڈ درست نہیں۔','auth/wrong-password':'پاس ورڈ درست نہیں۔','auth/user-not-found':'اس نام سے کوئی اکاؤنٹ نہیں ملا۔',
  'auth/invalid-email':'ای میل یا یوزر نیم درست نہیں۔','auth/email-already-in-use':'یہ یوزر نیم / ای میل پہلے سے استعمال میں ہے۔','auth/weak-password':'پاس ورڈ کم از کم 6 حروف کا رکھیں۔',
  'auth/too-many-requests':'بہت زیادہ کوششیں ہو گئیں۔ کچھ دیر بعد دوبارہ کوشش کریں۔','auth/network-request-failed':'انٹرنیٹ کنکشن نہیں ہے۔ چیک کر کے دوبارہ کوشش کریں۔',
  'auth/operation-not-allowed':'یہ طریقہ ابھی فعال نہیں۔ ایڈمن سے رابطہ کریں۔','auth/user-disabled':'یہ اکاؤنٹ بند کر دیا گیا ہے۔','auth/account-exists-with-different-credential':'اس ای میل سے دوسرے طریقے سے اکاؤنٹ بنا ہوا ہے۔',
  'mq/signup-closed':'فی الحال نئے اکاؤنٹ بنانا بند ہے۔ ایڈمن سے رابطہ کریں۔','mq/username':'یوزر نیم 3 تا 20 حروف: انگریزی حروف، اعداد یا _ استعمال کریں۔','mq/generic':'کچھ گڑبڑ ہو گئی۔ دوبارہ کوشش کریں۔'
};
function errText(c){ return ERR[c]||ERR['mq/generic']; }
var G=MQ.login={ handlers:{}, user:null, mode:'in', emailMode:false };
G.errText=errText;

/* ---------- screens ---------- */
G.show=function(state,info){
  info=info||{}; ov.style.display=''; document.documentElement.style.overflow='hidden';
  if(state==='loading'){
    ov.innerHTML='<div class="splash"><div class="gring"><div class="glogo">'+LOGO+'</div></div><h1>'+esc(BR.title)+'</h1></div>'; return;
  }
  if(state==='signin'){ authForm(info); return; }
  if(state==='reset'){ resetForm(info); return; }
  if(state==='pending'||state==='blocked'||state==='expired'){ statusCard(state,info); return; }
  if(state==='maintenance'){
    frame('<div class="gstate"><div class="bi">'+I.tool+'</div><h2>سائٹ کی دیکھ بھال جاری ہے</h2><p>'+esc(info.msg||'کچھ دیر بعد دوبارہ آئیں۔ شکریہ!')+'</p></div><button class="sbtn" id="g-out" type="button">سائن آؤٹ</button>','',false);
    on('g-out',function(){ G.handlers.signOut&&G.handlers.signOut(); }); return;
  }
  if(state==='devices'){
    frame('<div class="gstate"><div class="bi">'+I.alert+'</div><h2>ڈیوائسز کی حد پوری ہو گئی</h2><p>اس اکاؤنٹ پر اجازت شدہ ڈیوائسز پہلے ہی استعمال ہو چکی ہیں۔ نئی ڈیوائس کے لیے ایڈمن سے رابطہ کریں۔</p></div><button class="sbtn" id="g-out" type="button">سائن آؤٹ</button>','',false);
    on('g-out',function(){ G.handlers.signOut&&G.handlers.signOut(); }); return;
  }
  if(state==='error'){
    frame('<div class="gstate"><div class="bi">'+I.wifi+'</div><h2>رابطہ نہیں ہو سکا</h2><p>'+esc(info.msg||'اکاؤنٹ کی جانچ نہیں ہو سکی۔ انٹرنیٹ چیک کر کے دوبارہ کوشش کریں۔')+'</p></div><button class="pbtn" id="g-retry" type="button">دوبارہ کوشش کریں</button>');
    on('g-retry',function(){ location.reload(); }); return;
  }
};

function authForm(info){
  var up=G.mode==='up', em=G.emailMode;
  var idLabel=up?(em?'ای میل':'یوزر نیم'):'یوزر نیم یا ای میل';
  frame(
    '<button class="gbtn" id="g-google" type="button">'+GOOGLE+'<span>گوگل کے ساتھ جاری رکھیں</span></button>'
   +'<div class="gor">یا</div>'
   +'<div class="tabs"><button type="button" id="t-in" class="'+(up?'':'on')+'">سائن اِن</button><button type="button" id="t-up" class="'+(up?'on':'')+'">نیا اکاؤنٹ</button></div>'
   +(info.err?'<div class="gerr">'+I.alert+'<span>'+esc(info.err)+'</span></div>':'')
   +(info.ok?'<div class="okm">'+I.check+'<span>'+esc(info.ok)+'</span></div>':'')
   +'<form id="g-form" novalidate>'
   +(up?'<label for="f-name">پورا نام</label><div class="fld" id="w-name">'+I.user+'<input id="f-name" autocomplete="name" maxlength="60" placeholder="Your name"></div><div class="fe" id="e-name"></div>':'')
   +'<label for="f-id">'+idLabel+'</label><div class="fld" id="w-id">'+(up&&em||!up&&false?I.mail:I.at)+'<input id="f-id" autocomplete="'+(up&&em?'email':'username')+'" autocapitalize="none" autocorrect="off" spellcheck="false" placeholder="'+(up&&!em?'username':(up?'name@example.com':'username / email'))+'"></div>'
   +(up&&!em?'<div class="hint">3 تا 20 حروف: a-z، 0-9 یا _</div>':'')+'<div class="fe" id="e-id"></div>'
   +'<label for="f-pw">پاس ورڈ</label><div class="fld" id="w-pw">'+I.lock+'<input id="f-pw" type="password" autocomplete="'+(up?'new-password':'current-password')+'" placeholder="••••••••"><button type="button" class="eye" id="g-eye" aria-label="پاس ورڈ دکھائیں">'+I.eye+'</button></div>'
   +(up?'<div class="hint">کم از کم 6 حروف</div>':'')+'<div class="fe" id="e-pw"></div>'
   +'<button class="pbtn" id="g-submit" type="submit" style="margin-top:16px"><span>'+(up?'اکاؤنٹ بنائیں':'سائن اِن')+'</span></button></form>'
   +(up?'<button class="lnk" id="g-mode" type="button">'+(em?'یوزر نیم سے بنائیں':'ای میل سے بنائیں')+'</button>':'<button class="lnk" id="g-forgot" type="button">پاس ورڈ بھول گئے؟</button>')
  ,up?'نیا اکاؤنٹ بنائیں':'اسباق دیکھنے کے لیے سائن اِن کریں');
  var form=$('g-form'), submit=$('g-submit');
  on('g-google',function(){ var b=$('g-google'); busyBtn(b,true,true); Promise.resolve(G.handlers.signIn&&G.handlers.signIn()).then(function(){ if($('g-google')) busyBtn($('g-google'),false); }); });
  on('t-in',function(){ G.mode='in'; authForm({}); }); on('t-up',function(){ G.mode='up'; authForm({}); });
  on('g-mode',function(){ G.emailMode=!G.emailMode; authForm({}); });
  on('g-forgot',function(){ G.show('reset',{}); });
  var eye=$('g-eye'); eye.onclick=function(){ var p=$('f-pw'),h=p.type==='password'; p.type=h?'text':'password'; eye.innerHTML=h?I.eyeoff:I.eye; eye.setAttribute('aria-label',h?'پاس ورڈ چھپائیں':'پاس ورڈ دکھائیں'); };
  function fe(k,msg){ var w=$('w-'+k),e=$('e-'+k); if(w) w.classList.toggle('bad',!!msg); if(e) e.textContent=msg||''; return !msg; }
  ['name','id','pw'].forEach(function(k){ var i=$('f-'+k); if(i) i.addEventListener('input',function(){ fe(k,''); }); });
  form.onsubmit=function(ev){
    ev.preventDefault();
    var name=up?$('f-name').value.trim():'', id=$('f-id').value.trim(), pw=$('f-pw').value, ok=true;
    if(up&&name.length<2) ok=fe('name','اپنا نام لکھیں۔')&&ok;
    if(!id) ok=fe('id',up?(em?'ای میل لکھیں۔':'یوزر نیم لکھیں۔'):'یوزر نیم یا ای میل لکھیں۔')&&ok;
    else if(up&&em&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(id)) ok=fe('id','ای میل درست نہیں۔')&&ok;
    else if(up&&!em&&!/^[a-zA-Z0-9_]{3,20}$/.test(id)) ok=fe('id',errText('mq/username'))&&ok;
    if(!pw) ok=fe('pw','پاس ورڈ لکھیں۔')&&ok; else if(up&&pw.length<6) ok=fe('pw',errText('auth/weak-password'))&&ok;
    if(!ok) return;
    busyBtn(submit,true);
    var p=up?(G.handlers.emailSignUp&&G.handlers.emailSignUp({name:name,id:id,password:pw,email:em})):(G.handlers.emailSignIn&&G.handlers.emailSignIn({id:id,password:pw}));
    Promise.resolve(p).then(function(code){
      if(code&&$('g-submit')){
        busyBtn($('g-submit'),false);
        var box=ov.querySelector('.gcard'), old=box.querySelector('.gerr'); if(old) old.remove();
        box.insertAdjacentHTML('afterbegin','<div class="gerr">'+I.alert+'<span>'+esc(errText(code))+'</span></div>');
      }
    });
  };
}
function resetForm(info){
  frame((info.err?'<div class="gerr">'+I.alert+'<span>'+esc(info.err)+'</span></div>':'')+(info.ok?'<div class="okm">'+I.check+'<span>'+esc(info.ok)+'</span></div>':'')
   +'<p style="margin:0 0 4px;font-size:.92rem;opacity:.82">اپنا ای میل لکھیں؛ ہم پاس ورڈ بدلنے کا لنک بھیج دیں گے۔</p>'
   +'<form id="g-rform" novalidate><label for="f-id">ای میل</label><div class="fld" id="w-id">'+I.mail+'<input id="f-id" type="email" autocomplete="email" autocapitalize="none" placeholder="name@example.com"></div><div class="fe" id="e-id"></div>'
   +'<button class="pbtn" id="g-submit" type="submit" style="margin-top:14px"><span>لنک بھیجیں</span></button></form>'
   +'<p class="hint" style="text-align:center;margin-top:10px">اگر آپ نے صرف یوزر نیم سے اکاؤنٹ بنایا تھا تو ایڈمن سے واٹس ایپ پر رابطہ کریں۔</p>'
   +'<button class="lnk" id="g-back" type="button">← سائن اِن پر واپس</button>','پاس ورڈ بحال کریں');
  on('g-back',function(){ G.mode='in'; authForm({}); });
  $('g-rform').onsubmit=function(ev){
    ev.preventDefault(); var v=$('f-id').value.trim();
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)){ $('w-id').classList.add('bad'); $('e-id').textContent='ای میل درست نہیں۔'; return; }
    busyBtn($('g-submit'),true);
    Promise.resolve(G.handlers.reset&&G.handlers.reset(v)).then(function(code){
      if(code==='ok') G.show('reset',{ok:'لنک بھیج دیا گیا ہے۔ اپنا ان باکس (اور اسپیم) چیک کریں۔'}); else G.show('reset',{err:errText(code)});
    });
  };
}
function statusCard(state,info){
  var m={
    pending:{ic:I.hourglass,h:'منظوری کا انتظار',p:'آپ کی درخواست ایڈمن کو بھیج دی گئی ہے۔ منظوری کے بعد اسباق کھل جائیں گے۔'},
    blocked:{ic:I.ban,h:'رسائی بند ہے',p:'اس اکاؤنٹ کے لیے رسائی فی الحال بند ہے۔ مزید معلومات کے لیے ایڈمن سے رابطہ کریں۔'},
    expired:{ic:I.clock,h:'رسائی کی مدت ختم',p:'آپ کی رسائی کی مدت ختم ہو چکی ہے۔ تجدید کے لیے ایڈمن سے رابطہ کریں۔'}
  }[state];
  var text=encodeURIComponent(BR.waMsg?BR.waMsg+(info.email||info.name||''):'السلام علیکم! '+BR.title+' سائٹ کے لیے میری رسائی کا معاملہ دیکھ لیں۔ میرا اکاؤنٹ: '+(info.email||info.name||''));
  frame('<div class="gstate"><div class="bi">'+m.ic+'</div><h2>'+m.h+'</h2><p>'+m.p+'</p>'+(info.email||info.name?'<span class="mail">'+esc(info.email||info.name)+'</span>':'')+'</div>'
    +(wa?'<a class="pbtn" href="https://wa.me/'+esc(wa)+'?text='+text+'" target="_blank" rel="noopener noreferrer">واٹس ایپ پر رابطہ کریں</a>':'')
    +(state==='pending'?'<button class="sbtn" id="g-re" type="button">دوبارہ جانچیں</button>':'')+'<button class="sbtn" id="g-out" type="button">سائن آؤٹ</button>');
  var re=$('g-re'); if(re) re.onclick=function(){ busyBtn(re,true,true); G.handlers.recheck&&G.handlers.recheck(); };
  on('g-out',function(){ G.handlers.signOut&&G.handlers.signOut(); });
}
G.hide=function(){ ov.style.display='none'; document.documentElement.style.overflow=''; };
if(!fast) G.show('loading');

/* ---------- lesson loaders: wait for approval, then read from the protected database ---------- */
var cache={};
MQ.chapters=MQ.chapters||{}; MQ.exercises=MQ.exercises||{};
MQ.load=function(id){
  if(MQ.chapters[id]) return Promise.resolve(MQ.chapters[id]);
  if(!MQ.ref(id)) return Promise.resolve(null);
  if(cache['c'+id]) return cache['c'+id];
  return cache['c'+id]=MQ.authReady.then(function(){ return MQ.fetchDoc('ch_'+id); }).then(function(o){ if(o) MQ.chapters[id]=o; else delete cache['c'+id]; return o; });
};
MQ.loadEx=function(id){
  if(MQ.exercises[id]) return Promise.resolve(MQ.exercises[id]);
  if(cache['e'+id]) return cache['e'+id];
  return cache['e'+id]=MQ.authReady.then(function(){ return MQ.fetchDoc('ex_'+id); }).then(function(o){ if(o) MQ.exercises[id]=o; else delete cache['e'+id]; return o; });
};
})();
