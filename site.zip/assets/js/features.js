/* Student-side extras: progress sync across devices, lesson-open counts, expiry / exam reminders,
   offline download, mistake reports and the per-account device limit.
   Loaded by auth.js once an account is approved. Every call is wrapped so a failure never breaks reading. */
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const TS = 'mq_ts', SKIP = { '_ts': 1 };
const jget = (k, d) => { try { return JSON.parse(localStorage.getItem(k) || '') || d; } catch (e) { return d; } };
const jset = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } };
const say = (MQ, m, ms) => { try { if (MQ.toast) MQ.toast(m, ms); else if (MQ.notify && MQ.notify.toast) MQ.notify.toast(m, 'info'); } catch (e) { } };
const nu = n => String(n);
const dnum = s => { const p = String(s).split('-').map(Number); return Math.round(Date.UTC(p[0], p[1] - 1, p[2]) / 864e5); };

/* ---------- 1. progress sync ---------- */
/* One document per student (progress/<uid>) shared by all three sites. Quran keys are stored bare ("read"), the Urdu / English
   sites store theirs as "ur:name" / "en:name", so every site only ever touches its own keys. */
const UNION = { read: 1, opens: 1, days: 1, readPages: 1, visitDates: 1 };
function startSync(c) {
  const { db, S, u, MQ } = c, ns = c.ns || '', ref = S.doc(db, 'progress', u.uid), pre = ns ? ns + ':' : 'mq:';
  let timer = null, busy = false;
  const docKey = sk => ns ? sk : sk.slice(3), storeKey = dk => ns ? dk : 'mq:' + dk, mine = dk => ns ? dk.indexOf(pre) === 0 : !/^(ur|en):/.test(dk);
  const bare = dk => ns ? dk.slice(pre.length) : dk;
  const stamps = () => jget(TS, {});
  const touch = sk => { if (sk.indexOf(pre) !== 0) return; const t = stamps(); t[docKey(sk)] = Date.now(); jset(TS, t); schedule(); };
  const schedule = () => { clearTimeout(timer); timer = setTimeout(push, 4000); };
  window.__mqTouch = touch;
  if (!ns && MQ.S && !MQ.S.__sync) {
    const set = MQ.S.set, del = MQ.S.del;
    MQ.S.set = function (k, v) { set.call(MQ.S, k, v); touch('mq:' + k); };
    MQ.S.del = function (k) { del.call(MQ.S, k); touch('mq:' + k); };
    MQ.S.__sync = 1;
  }
  const local = () => { const d = {}; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k && k.indexOf(pre) === 0 && k !== pre + '_ts') d[docKey(k)] = localStorage.getItem(k); } return d; };
  async function push() {
    if (busy || navigator.onLine === false) return; busy = true;
    try {
      const l = local(), t = stamps(), d = {}, tt = {};
      Object.keys(l).forEach(k => { d[k] = l[k]; tt[k] = t[k] || 1; });
      Object.keys(t).forEach(k => { if (!(k in l) && mine(k)) { d[k] = null; tt[k] = t[k]; } });
      await S.setDoc(ref, { d, t: tt, updatedAt: S.serverTimestamp() }, { merge: true });
    } catch (e) { }
    busy = false;
  }
  const parse = x => { try { return JSON.parse(x); } catch (e) { return undefined; } };
  const mergeUnion = (a, b, key) => {
    if (Array.isArray(a) && Array.isArray(b)) { const seen = {}, out = []; a.concat(b).forEach(v => { const k = JSON.stringify(v); if (!seen[k]) { seen[k] = 1; out.push(v); } }); return key === 'days' || key === 'visitDates' ? out.sort() : out; }
    if (a && b && typeof a === 'object' && typeof b === 'object' && !Array.isArray(a) && !Array.isArray(b)) {
      const o = Object.assign({}, b, a); Object.keys(a).forEach(k => { if (typeof a[k] === 'number' && typeof b[k] === 'number') o[k] = key === 'opens' ? Math.max(a[k], b[k]) : Math.min(a[k], b[k]) || a[k]; }); return o;
    }
    return undefined;
  };
  async function pull() {
    let snap; try { snap = await S.getDoc(ref); } catch (e) { return; }
    if (!snap.exists()) { push(); return; }
    const r = snap.data(), rd = r.d || {}, rt = r.t || {}, lt = stamps(); let changed = false;
    Object.keys(rd).forEach(dk => {
      if (!mine(dk)) return;
      const sk = storeKey(dk), a = rt[dk] || 0, b = lt[dk] || 0, cur = localStorage.getItem(sk), bk = bare(dk);
      if (UNION[bk] && rd[dk] !== null) {
        const m = mergeUnion(parse(cur), parse(rd[dk]), bk);
        if (m !== undefined) { const t = JSON.stringify(m); if (t !== cur) { localStorage.setItem(sk, t); changed = true; } lt[dk] = Math.max(a, b); return; }
      }
      if (a > b) {
        if (rd[dk] === null) { if (cur != null) { localStorage.removeItem(sk); changed = true; } }
        else if (rd[dk] !== cur) { localStorage.setItem(sk, rd[dk]); changed = true; }
        lt[dk] = a;
      }
    });
    jset(TS, lt);
    if (changed) {
      let done = false; try { done = sessionStorage.getItem('mq_synced_' + ns) === '1'; sessionStorage.setItem('mq_synced_' + ns, '1'); } catch (e) { }
      if (!done) { say(MQ, 'آپ کی پیش رفت بحال کر دی گئی'); setTimeout(() => location.reload(), 900); return; }
    }
    push();
  }
  /* lesson-open counter (feeds the admin "most opened lessons" list) */
  try {
    let id = '';
    if (!ns) { if (/section(\.html)?$/.test(location.pathname) && MQ.qs) id = MQ.qs('id') || ''; }
    else { const f = (location.pathname.split('/').pop() || 'index.html').replace(/\.html$/, ''); if (!/^(index|about|privacy|terms|share|me|bookmarks|flashcards|vocabulary|whatsnew|search|404)$/.test(f)) id = f; }
    if (id) { const k = ns ? ns + ':opens' : 'mq:opens', o = parse(localStorage.getItem(k)) || {}; o[id] = (o[id] || 0) + 1; localStorage.setItem(k, JSON.stringify(o)); touch(k); }
  } catch (e) { }
  addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') push(); });
  addEventListener('online', schedule);
  pull();
}

/* ---------- 2. local reminders shown in the bell ---------- */
function reminders(c) {
  const { MQ, expiresAt } = c, list = [], t0 = new Date(); t0.setHours(0, 0, 0, 0); const ts = t0.getTime();
  if (expiresAt) {
    const d = Math.ceil((expiresAt - Date.now()) / 864e5);
    if (d > 0 && d <= 3) list.push({ id: 'exp' + ts, title: 'آپ کی رسائی جلد ختم ہو رہی ہے', body: 'آپ کی رسائی ' + nu(d) + ' دن میں ختم ہو جائے گی۔ تجدید کے لیے ایڈمن سے رابطہ کریں۔', type: 'warn', ts, exp: 0 });
  }
  const examDays = () => { try { if (MQ.examLeft) return MQ.examLeft(); const raw = localStorage.getItem(c.ns ? c.ns + ':examDate' : 'mq:exam'); if (!raw) return null; let v = raw; try { v = JSON.parse(raw); } catch (x) { } v = String(v || '').slice(0, 10); if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return null; const n = new Date(), t = n.getFullYear() + '-' + String(n.getMonth() + 1).padStart(2, '0') + '-' + String(n.getDate()).padStart(2, '0'), d = dnum(v) - dnum(t); return d < 0 ? null : d; } catch (x) { return null; } };
  try { const e = examDays(); if (e != null && e <= 60) list.push({ id: 'exam' + ts, title: e === 0 ? 'آج امتحان ہے' : 'امتحان میں ' + nu(e) + ' دن باقی', body: 'روزانہ تھوڑا تھوڑا دہرائیں۔ اللہ آپ کو کامیاب کرے۔', type: 'info', ts, exp: 0 }); } catch (e) { }
  MQ.localNotes = list; if (MQ.refreshNotes) MQ.refreshNotes();
}

/* ---------- 3. offline download ---------- */
async function offline(c, btn) {
  const keys = c.keys().filter(k => k !== '_rev'); if (!keys.length) { say(c.MQ, 'ابھی کوئی مواد دستیاب نہیں'); return; }
  const lab = btn.querySelector('span'), old = lab.textContent; btn.disabled = true; let n = 0, bad = 0;
  for (const k of keys) { try { const d = await c.MQ.fetchDoc(k); if (!d) bad++; } catch (e) { bad++; } lab.textContent = (++n) + ' / ' + keys.length; }
  btn.disabled = false; lab.textContent = old;
  say(c.MQ, bad ? 'کچھ اسباق ڈاؤن لوڈ نہیں ہوئے — انٹرنیٹ چیک کریں' : 'سب اسباق آف لائن کے لیے محفوظ ہو گئے', 3200);
}

/* ---------- 4. mistake report ---------- */
function report(c) {
  const old = document.getElementById('mq-rep'); if (old) old.remove();
  const w = document.createElement('div'); w.id = 'mq-rep';
  w.style.cssText = 'position:fixed;inset:0;z-index:2147483000;background:rgba(0,0,0,.45);display:flex;align-items:flex-end;justify-content:center';
  w.innerHTML = '<div dir="rtl" style="background:var(--card,#fff);color:var(--text,#222);width:100%;max-width:520px;border-radius:22px 22px 0 0;padding:18px 16px calc(18px + env(safe-area-inset-bottom));font-family:inherit">' +
    '<h3 style="margin:0 0 4px;font-size:1.05rem">غلطی کی اطلاع دیں</h3><p style="margin:0 0 10px;font-size:.85rem;opacity:.7">جس صفحے پر ہیں اس کا حوالہ خود بخود بھیج دیا جائے گا۔</p>' +
    '<textarea id="mq-rep-t" maxlength="500" rows="4" style="width:100%;box-sizing:border-box;border:1px solid var(--border,#ccc);border-radius:12px;padding:10px;font:inherit;background:transparent;color:inherit;resize:vertical" placeholder="کیا غلطی ہے؟"></textarea>' +
    '<div style="display:flex;gap:8px;margin-top:10px"><button id="mq-rep-s" type="button" style="flex:1;border:0;border-radius:12px;padding:12px;font:inherit;font-weight:700;background:var(--primary,#2A7459);color:#fff">بھیجیں</button><button id="mq-rep-x" type="button" style="border:1px solid var(--border,#ccc);border-radius:12px;padding:12px 16px;font:inherit;background:transparent;color:inherit">بند کریں</button></div></div>';
  document.body.appendChild(w);
  const close = () => w.remove(); w.onclick = e => { if (e.target === w) close(); }; document.getElementById('mq-rep-x').onclick = close;
  document.getElementById('mq-rep-s').onclick = async function () {
    const m = document.getElementById('mq-rep-t').value.trim(); if (m.length < 3) { say(c.MQ, 'پہلے غلطی لکھیں'); return; }
    this.disabled = true;
    try {
      await c.S.addDoc(c.S.collection(c.db, 'feedback'), { uid: c.u.uid, name: c.name || '', email: c.u.email || '', page: location.pathname.split('/').pop() + location.search, msg: m, status: 'new', createdAt: c.S.serverTimestamp() });
      close(); say(c.MQ, 'شکریہ! آپ کی اطلاع بھیج دی گئی');
    } catch (e) { this.disabled = false; say(c.MQ, 'نہیں بھیجا جا سکا — انٹرنیٹ چیک کریں'); }
  };
}

/* ---------- 5. device limit (soft: enforced by the app, not by the server) ---------- */
async function devices(c) {
  const limit = +(c.site() || {}).deviceLimit || 0; let id = ''; try { id = localStorage.getItem('mq_dev') || ''; if (!id) { id = Math.random().toString(36).slice(2, 10) + Date.now().toString(36); localStorage.setItem('mq_dev', id); } } catch (e) { return true; }
  const col = c.S.collection(c.db, 'users', c.u.uid, 'devices'), me = c.S.doc(col, id);
  try {
    const own = await c.S.getDoc(me);
    if (own.exists()) { c.S.updateDoc(me, { last: c.S.serverTimestamp() }).catch(() => { }); return true; }
    if (limit > 0) { const all = await c.S.getDocs(col); if (all.size >= limit) return false; }
    await c.S.setDoc(me, { ua: (navigator.userAgent || '').slice(0, 120), first: c.S.serverTimestamp(), last: c.S.serverTimestamp() });
  } catch (e) { }
  return true;
}

export function init(c) {
  try { reminders(c); } catch (e) { }
  if (!c.isAdmin) { try { startSync(c); } catch (e) { } }
  return { offline: btn => offline(c, btn), report: () => report(c), devices: () => devices(c) };
}
